-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2018 at 01:06 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `karatte`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `role`) VALUES
(1, 'anoop', 'anoop', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` varchar(25) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phoneno` varchar(100) NOT NULL,
  `emailid` varchar(100) NOT NULL,
  `currentstatus` varchar(100) NOT NULL,
  `upload` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstname`, `lastname`, `gender`, `dob`, `address`, `phoneno`, `emailid`, `currentstatus`, `upload`) VALUES
(' ktw004', 'abin', 'sss', 'Male', '06/04/2018', 'aasd', '9632558', 'A@gmail.com', 'white', 'photo0026.jpg'),
(' ktw007', 'abin', 'aaass', 'Male', '06/04/2018', 'sas', '2556996696', 'Ad@gmail.com', 'white', 'photo0030 - Copy.jpg'),
(' w7y', 'bbbb', 'bbb', 'Male', '06/04/2018', 'vbbbb', '7878787878', 'Ad@gmail.com', 'orenge', 'photo0048.jpg'),
(' yanoop', 'anoopaaaaaaaaaa', 'asdsa', 'Male', '06/04/2018', 'asdasdfafs', '9874444444', 'Ad@gmail.com', 'orenge', 'photo0016.jpg'),
('abcd', 'anoop', 'asd', 'Male', '06/04/2018', 'sdasd', '7878787878', 'A@gmail.com', 'orenge', ''),
('anooppm', 'aasdsad', 'sdas', 'Male', '06/04/2018', 'sdsadfasdf', '98745777877', 'Ad@gmail.com', 'white', 'photo0049.jpg'),
('ayyo', 'aasdsad', 'asdsad', 'Male', '06/18/2018', 'asddas', '2556996696', 'A@gmail.com', 'orenge', 'anoop.jpg'),
('bbb', 'safas', 'sada', 'sad', 'sadas', 'sad', 'dsada', 'ssada', 'sadas', 'das'),
('k8a', 'aaa', 'aaa', 'aaa', 'aaa', 'aa', 'aa', 'aaa@gmail.com', 'aaa', 'aaa');
